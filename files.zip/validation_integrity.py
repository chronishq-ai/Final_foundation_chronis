"""
Sprint 15 — Phase N (Validation Integrity)
Tickets: S15.1 (N0 — destroy the disconnected benchmark illusion),
         S15.2 (N1/R — prevent metric contamination via mandatory manifest)

Open finding this closes (verified findings ledger, P0):
    ID: S15.1
    Finding: "divergence >75% evidence from disconnected toy harness"
    V2 disposition: N0

This module provides:
  1. DatasetClass enum (§31.7) — every benchmark result must be tagged and the
     tag must survive downstream reporting (a synthetic result can never
     silently become "real-world validation").
  2. BenchmarkManifest (S15.2) — the required provenance fields; a result
     without one is not release evidence.
  3. A PipelineStageTracker (S15.1/N0) that forces a benchmark to declare
     which real stages it actually passed through. If any required stage
     (feature_contract -> hssm -> nssm -> divergence_engine -> claims_path)
     is missing, the result MUST be labeled "synthetic-formula sanity check"
     and is barred from being reported as a production validation number.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class DatasetClass(str, Enum):
    SYNTHETIC = "SYNTHETIC"
    PLANTED = "PLANTED"
    SURROGATE = "SURROGATE"
    PILOT = "PILOT"
    REAL_USER = "REAL_USER"


REQUIRED_PIPELINE_STAGES = (
    "raw_feature_generation",
    "feature_contract",
    "hssm",
    "nssm",
    "divergence_engine",
    "claims_admissibility",
)


class DisconnectedHarnessError(Exception):
    """Raised when code tries to report a full validation result without
    having actually passed through every required real pipeline stage."""


@dataclass
class PipelineStageTracker:
    """
    Call `.mark(stage)` as each real component actually executes. This is
    meant to be threaded through the real HSSM / NSSM / Divergence Engine /
    Claims path code (not simulated) so the tracker can only be satisfied by
    genuine execution, not by a harness that computes accuracy from formulas.
    """
    stages_passed: set = field(default_factory=set)

    def mark(self, stage: str) -> None:
        if stage not in REQUIRED_PIPELINE_STAGES:
            raise ValueError(f"unknown pipeline stage: {stage!r}")
        self.stages_passed.add(stage)

    def is_fully_connected(self) -> bool:
        return set(REQUIRED_PIPELINE_STAGES).issubset(self.stages_passed)

    def missing_stages(self) -> list:
        return [s for s in REQUIRED_PIPELINE_STAGES if s not in self.stages_passed]


@dataclass
class BenchmarkManifest:
    """S15.2 — required fields; a result without these is not release evidence."""
    repository_commit: str
    package_versions: dict
    model_versions: dict
    dataset_revision: str
    random_seeds: list
    configuration_hash: str
    benchmark_version: str
    dataset_class: DatasetClass

    def config_hash_matches(self, config: dict) -> bool:
        computed = hashlib.sha256(
            json.dumps(config, sort_keys=True).encode("utf-8")
        ).hexdigest()
        return computed == self.configuration_hash

    def to_dict(self) -> dict:
        d = dict(
            repository_commit=self.repository_commit,
            package_versions=self.package_versions,
            model_versions=self.model_versions,
            dataset_revision=self.dataset_revision,
            random_seeds=self.random_seeds,
            configuration_hash=self.configuration_hash,
            benchmark_version=self.benchmark_version,
            dataset_class=self.dataset_class.value,
        )
        return d


@dataclass
class ValidationResult:
    label: str
    metric_name: str
    metric_value: float
    tracker: PipelineStageTracker
    manifest: Optional[BenchmarkManifest]

    def __post_init__(self):
        # N0: force honest labeling if not fully pipeline-connected.
        if not self.tracker.is_fully_connected():
            missing = self.tracker.missing_stages()
            if not self.label.startswith("synthetic-formula sanity check"):
                self.label = f"synthetic-formula sanity check ({self.label})"
            self._disconnected = True
            self._missing_stages = missing
        else:
            self._disconnected = False
            self._missing_stages = []

        # N1: no manifest, no release evidence.
        if self.manifest is None:
            self._release_eligible = False
        else:
            self._release_eligible = not self._disconnected

    def is_release_evidence(self) -> bool:
        return self._release_eligible

    def assert_not_reportable_as_production_validation(self) -> None:
        """Call this in CI to hard-fail a build that tries to publish a
        disconnected-harness number as if it were production validation."""
        if self._disconnected:
            raise DisconnectedHarnessError(
                f"'{self.label}' is missing pipeline stages "
                f"{self._missing_stages} and cannot be reported as production "
                f"validation evidence (N0). It may only appear labeled as a "
                f"synthetic-formula sanity check, kept separate from release claims."
            )
        if self.manifest is None:
            raise DisconnectedHarnessError(
                f"'{self.label}' has no BenchmarkManifest and is therefore not "
                f"release evidence (N1)."
            )


# ---------------------------------------------------------------------------
# Negative tests (test-of-the-test rule, §31.4)
# ---------------------------------------------------------------------------

def _run_negative_tests() -> None:
    # 1. The historical defect: a toy harness claims ">75% accuracy" without
    #    ever touching HSSM/NSSM/Divergence/Claims. Must be forced into the
    #    "synthetic-formula sanity check" label and barred from release.
    toy_tracker = PipelineStageTracker()
    toy_tracker.mark("raw_feature_generation")  # only the first stage — a toy formula harness
    toy_result = ValidationResult(
        label="four divergence types >75% accuracy",
        metric_name="accuracy",
        metric_value=0.81,
        tracker=toy_tracker,
        manifest=None,
    )
    assert toy_result.label.startswith("synthetic-formula sanity check")
    assert toy_result.is_release_evidence() is False
    try:
        toy_result.assert_not_reportable_as_production_validation()
        raise AssertionError("expected DisconnectedHarnessError")
    except DisconnectedHarnessError:
        pass

    # 2. Fully connected pipeline + manifest -> legitimate release evidence.
    real_tracker = PipelineStageTracker()
    for stage in REQUIRED_PIPELINE_STAGES:
        real_tracker.mark(stage)

    manifest = BenchmarkManifest(
        repository_commit="a1b2c3d4",
        package_versions={"chronis-hssm": "1.4.0", "chronis-nssm": "1.2.1"},
        model_versions={"hssm": "hssm-v3", "nssm": "nssm-v2"},
        dataset_revision="planted-2026-09-01",
        random_seeds=[13, 14, 15],
        configuration_hash=hashlib.sha256(
            json.dumps({"k": 5}, sort_keys=True).encode("utf-8")
        ).hexdigest(),
        benchmark_version="v1.0.0",
        dataset_class=DatasetClass.PLANTED,
    )
    real_result = ValidationResult(
        label="four divergence types accuracy (planted benchmark)",
        metric_name="accuracy",
        metric_value=0.81,
        tracker=real_tracker,
        manifest=manifest,
    )
    assert real_result.is_release_evidence() is True
    real_result.assert_not_reportable_as_production_validation()  # must not raise

    # 3. Fully connected but NO manifest -> still not release evidence (N1).
    real_result_no_manifest = ValidationResult(
        label="connected pipeline, no manifest",
        metric_name="accuracy",
        metric_value=0.81,
        tracker=real_tracker,
        manifest=None,
    )
    assert real_result_no_manifest.is_release_evidence() is False

    print("All S15.1/S15.2 (N0/N1) negative tests passed.")


if __name__ == "__main__":
    _run_negative_tests()
