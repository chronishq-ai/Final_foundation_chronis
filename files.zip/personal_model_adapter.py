"""
Sprint 13 — Phase J (Personal Model / Shared Model Isolation)
Tickets: S13.1 (J1 — PEFT/personal model fidelity), J0 (shared base immutability)

Implements:
  - Real per-user PEFT adapter metadata (not a hashed-vector placeholder)
  - allowed_read_path() / allowed_write_path() as SEPARATE checks (J0)
  - Filename validation independent of path resolution (J0)

This module intentionally does NOT implement the adapter training loop itself
(that depends on your model framework — e.g. peft/LoRA via transformers/bitsandbytes).
It implements the CONTRACT the spec requires around any adapter: the metadata
record, the path-isolation gate, and the checkpoint provenance chain.
"""

from __future__ import annotations

import re
import hashlib
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Optional


SHARED_NAMESPACE_PREFIX = "_shared"

# Filenames must be validated independently of path *resolution* (J0) —
# resolving ../ tricks a naive prefix check even when the final path looks safe.
_SAFE_FILENAME_RE = re.compile(r"^[A-Za-z0-9._-]+$")


class PathIsolationError(Exception):
    """Raised when a personal-path operation would touch the shared namespace."""


def _normalize(path: str) -> PurePosixPath:
    # Collapse to a pure posix path with no '..' traversal tolerated.
    p = PurePosixPath(path)
    if ".." in p.parts:
        raise PathIsolationError(f"path traversal rejected: {path!r}")
    return p


def validate_filename(filename: str) -> None:
    """Independent filename check — does not rely on path resolution at all."""
    if not filename or filename in (".", ".."):
        raise PathIsolationError(f"invalid filename: {filename!r}")
    if not _SAFE_FILENAME_RE.match(filename):
        raise PathIsolationError(f"filename fails safety pattern: {filename!r}")
    if filename.startswith(SHARED_NAMESPACE_PREFIX):
        raise PathIsolationError(f"filename impersonates shared namespace: {filename!r}")


def allowed_read_path(path: str, user_id: str) -> bool:
    """
    Personal read paths may resolve into _shared (shared base checkpoints are
    legitimately readable — S13.1 allows reuse of the shared base checkpoint).
    Reads are NOT blocked from _shared, only writes are (per J0).
    """
    normalized = _normalize(path)
    validate_filename(normalized.name)
    return True


def allowed_write_path(path: str, user_id: str) -> bool:
    """
    A resolved path under _shared is ALWAYS denied to user write APIs (J0),
    with no exceptions — including for admin-looking user_ids. This is a hard
    gate, checked independently from allowed_read_path.
    """
    normalized = _normalize(path)
    validate_filename(normalized.name)

    parts = normalized.parts
    if SHARED_NAMESPACE_PREFIX in parts:
        return False

    # Personal writes must additionally be scoped under the caller's own user_id
    # directory — prevents cross-user writes even inside the personal namespace.
    if len(parts) < 2 or parts[0] != "users" or parts[1] != user_id:
        return False

    return True


@dataclass(frozen=True)
class PersonalCheckpointRecord:
    """
    Every personal checkpoint must record these fields (S13.1, verbatim from spec).
    A hashed-vector placeholder does not satisfy this contract — adapter_type
    must name a real per-user adaptation method (e.g. 'lora', 'ia3', 'prefix-tuning')
    or another explicitly approved equivalent, and adapter_path must point at real
    trained weights, not a fixed-size hash of user data.
    """

    base_model_id: str
    base_model_hash: str
    adapter_type: str          # e.g. "lora", "ia3" — NOT "hashed_vector"
    adapter_version: str
    training_data_revision: str
    training_window_start: datetime
    training_window_end: datetime
    owner_user_id: str
    created_at: datetime
    adapter_path: str          # must resolve OUTSIDE _shared, under users/<owner_user_id>/

    def __post_init__(self):
        if self.adapter_type.strip().lower() in {"hashed_vector", "hash", "placeholder"}:
            raise ValueError(
                "adapter_type indicates a hashed-vector placeholder, which is not "
                "equivalent to PEFT (S13.1). Use a real adaptation method or an "
                "explicitly approved equivalent."
            )
        if not allowed_write_path(self.adapter_path, self.owner_user_id):
            raise PathIsolationError(
                f"adapter_path {self.adapter_path!r} is not a valid personal write "
                f"path for user {self.owner_user_id!r} (J0)."
            )

    def to_manifest(self) -> dict:
        d = asdict(self)
        d["training_window_start"] = self.training_window_start.isoformat()
        d["training_window_end"] = self.training_window_end.isoformat()
        d["created_at"] = self.created_at.isoformat()
        return d


def hash_base_checkpoint(checkpoint_bytes: bytes) -> str:
    """Deterministic base_model_hash for checkpoint provenance (S13.1)."""
    return "sha256:" + hashlib.sha256(checkpoint_bytes).hexdigest()


# ---------------------------------------------------------------------------
# S13.5 — negative tests (test-of-the-test rule, §31.4): each test below must
# FAIL if you reintroduce the historical defect (a hashed-vector placeholder,
# or a write path that lands in _shared).
# ---------------------------------------------------------------------------

def _run_negative_tests() -> None:
    # 1. Hashed-vector placeholder must be rejected.
    try:
        PersonalCheckpointRecord(
            base_model_id="chronis-base-1",
            base_model_hash="sha256:deadbeef",
            adapter_type="hashed_vector",
            adapter_version="v1",
            training_data_revision="rev-001",
            training_window_start=datetime.now(timezone.utc),
            training_window_end=datetime.now(timezone.utc),
            owner_user_id="u123",
            created_at=datetime.now(timezone.utc),
            adapter_path="users/u123/adapter.bin",
        )
        raise AssertionError("expected ValueError for hashed_vector placeholder")
    except ValueError:
        pass

    # 2. Write into _shared must be denied, even for a "valid-looking" path.
    assert allowed_write_path("_shared/base/model.bin", "u123") is False

    # 3. Cross-user write must be denied.
    assert allowed_write_path("users/other_user/adapter.bin", "u123") is False

    # 4. Path traversal must be rejected independent of resolution.
    try:
        allowed_write_path("users/u123/../_shared/model.bin", "u123")
        raise AssertionError("expected PathIsolationError for traversal")
    except PathIsolationError:
        pass

    # 5. Legitimate personal write path must be allowed.
    assert allowed_write_path("users/u123/adapter.bin", "u123") is True

    # 6. Reads MAY reach _shared (reuse of shared base is allowed).
    assert allowed_read_path("_shared/base/chronis-base-1.bin", "u123") is True

    print("All S13.1/J0 negative tests passed.")


if __name__ == "__main__":
    _run_negative_tests()
