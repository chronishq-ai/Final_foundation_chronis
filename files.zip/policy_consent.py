"""
Sprint 14 — Phase L0 (Per-rule consent enforcement)
Ticket: S14.1

Spec requirement (verbatim intent): every policy rule's min_consent_tier must
actually participate in the authorization decision. A global default tier is
NOT sufficient if individual rules declare different minimums.

Required negative test (spec, L0):
    rule.min_consent_tier = 3
    user.consent = 2
    Expected: DENY
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Decision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"


@dataclass(frozen=True)
class PolicyRule:
    rule_id: str
    min_consent_tier: int  # per-rule minimum — this is the field that must be READ


@dataclass(frozen=True)
class User:
    user_id: str
    consent: int  # the user's granted consent tier


@dataclass(frozen=True)
class AuthorizationResult:
    decision: Decision
    rule_id: str
    required_tier: int
    actual_tier: int
    audit_event: dict


def authorize(rule: PolicyRule, user: User) -> AuthorizationResult:
    """
    The ONLY correct implementation reads rule.min_consent_tier per call.
    A defect this spec explicitly calls out: a global default tier used
    instead of (or in place of) the rule's own declared minimum.
    """
    required = rule.min_consent_tier          # <-- must be read from the rule, not a global
    actual = user.consent

    decision = Decision.ALLOW if actual >= required else Decision.DENY

    audit_event = {
        "rule_id": rule.rule_id,
        "user_id": user.user_id,
        "required_tier": required,
        "actual_tier": actual,
        "decision": decision.value,
    }
    # Every denied path must produce an auditable security event (L2 requirement,
    # enforced here at the point of decision so no caller can skip it).
    if decision is Decision.DENY:
        _emit_security_event(audit_event)

    return AuthorizationResult(
        decision=decision,
        rule_id=rule.rule_id,
        required_tier=required,
        actual_tier=actual,
        audit_event=audit_event,
    )


def _emit_security_event(event: dict) -> None:
    # Replace with your real audit sink (structured log / SIEM / event bus).
    # Kept as a hook so this module has no hidden external dependency.
    print(f"[SECURITY_EVENT] policy denial: {event}")


# ---------------------------------------------------------------------------
# Required negative test (spec, L0) + supporting cases.
# Test-of-the-test rule (§31.4): reintroduce the historical defect below (a
# GLOBAL_DEFAULT_TIER ignoring the per-rule value) and confirm this test fails.
# ---------------------------------------------------------------------------

def _run_negative_tests() -> None:
    # --- Spec's exact required negative test ---
    rule = PolicyRule(rule_id="export.personal_data", min_consent_tier=3)
    user = User(user_id="u1", consent=2)
    result = authorize(rule, user)
    assert result.decision is Decision.DENY, "L0 negative test FAILED: expected DENY"

    # --- Sanity: sufficient consent allows ---
    user_ok = User(user_id="u2", consent=3)
    result_ok = authorize(rule, user_ok)
    assert result_ok.decision is Decision.ALLOW

    # --- Per-rule differentiation: two rules, different minimums, same user ---
    low_rule = PolicyRule(rule_id="read.own_retrieval", min_consent_tier=1)
    high_rule = PolicyRule(rule_id="model.train_on_bystander", min_consent_tier=4)
    mid_user = User(user_id="u3", consent=2)
    assert authorize(low_rule, mid_user).decision is Decision.ALLOW
    assert authorize(high_rule, mid_user).decision is Decision.DENY, (
        "per-rule minimum not respected — looks like a global default tier bug"
    )

    print("All S14.1/L0 negative tests passed.")


def _demonstrate_the_historical_defect() -> None:
    """
    Shows the failure mode the spec is guarding against: a GLOBAL default tier
    that ignores rule.min_consent_tier. This is deliberately NOT wired into
    authorize() above — it exists so reviewers can see what "wrong" looks like
    and confirm the real implementation doesn't collapse into it.
    """
    GLOBAL_DEFAULT_TIER = 1

    def buggy_authorize(rule: PolicyRule, user: User) -> Decision:
        # BUG: ignores rule.min_consent_tier entirely.
        return Decision.ALLOW if user.consent >= GLOBAL_DEFAULT_TIER else Decision.DENY

    rule = PolicyRule(rule_id="export.personal_data", min_consent_tier=3)
    user = User(user_id="u1", consent=2)
    buggy_result = buggy_authorize(rule, user)
    assert buggy_result is Decision.ALLOW, "defect demo should show the bug ALLOWing"
    print(
        "Confirmed: a global-default-tier implementation would ALLOW this case "
        "(bug). The real authorize() above correctly DENYs it."
    )


if __name__ == "__main__":
    _run_negative_tests()
    _demonstrate_the_historical_defect()
